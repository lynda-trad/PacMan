public class Blue extends Gum
{
	/*
		Bleu
		100
		rien
	*/
	
	public Blue(int type, Coordinate c)
	{
		super(0, c);  
	}
}