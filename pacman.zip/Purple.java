public class Purple extends Gum
{
	/*
		Violet
		300
		pacman jaune pale
		Quand le pacman est invisible, il pourra traverser les fantomes sans perdre de vie.
	*/
	
	public Purple(int type, Coordinate c)
	{
		super(1, c);
	}
}