public class Green extends Gum
{
	/*
		Vert 
		1000 
		Modifie la structure du labyrinthe
	*/
	
	public Green(int type, Coordinate c) 
	{	
		super(3, c);
	}	
}
 